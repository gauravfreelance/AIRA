import React from "react";

const APPS = [
  {
    id: "google",
    title: "Google",
    // icon: "",
    desc: "Connect to Google AI's capabilities for documents and chat",
  },
  {
    id: "aws",
    title: "AWS",
    // icon: "",
    desc: "Connect to Google AI's capabilities for documents and chat",
  },
];

const ConnectToFavApps = () => {
  return <div>ConnectToFavApps</div>;
};

export default ConnectToFavApps;
