export const STRAPI_BASE_URL = "http://localhost:1337";
export const STRAPI_API_URL = "http://localhost:1337/api";
