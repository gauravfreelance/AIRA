import React from 'react'
import AIRAMonoLinesLeft from "../../components/AIRAMonoLinesLeft";
import { Box, Stack, Typography } from "@mui/material";
import Colors from "../../common/Colors";
import FinancialSupport from './FinancialSupport';
const Solution = () => {
  return (
    <Box sx={{ backgroundColor: "##F8F9FB", position: "relative" }}>
            <Stack
                sx={{ my: 10 }}
                alignItems="center"
                direction="row"
                justifyContent="space-between"
            >
                <Box sx={{ position: "relative" }}>
                    <div
                        style={{
                            position: "absolute",
                            top: -80,
                        }}
                    >
                        <AIRAMonoLinesLeft />
                    </div>
                </Box>
                <Typography
                    variant="h4"
                    sx={{
                        fontWeight: 600,
                        lineHeight: 1.2,
                        color: Colors.airaSecondary,
                        marginLeft: "100px",
                    }}
                >
                    Empowering <br />
                    <span style={{ color: "#200E32", fontWeight: 700 }}>
                        Communities Globally
                    </span>
                </Typography>
                <img
                    src="images/pricing/pricing_header.png"
                    alt="CSR Header"
                    style={{ width: "700px", height: "450px" }}
                />
            </Stack>
            <Box sx={{ backgroundColor: "#6755DF" }}>
        <Box sx={{ width: "70%", mx: "auto", mt: 4 }} direction="row" gap={1}>
          <FinancialSupport />
        </Box>
      </Box>
            </Box>
  )
}

export default Solution