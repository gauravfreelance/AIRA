import React from 'react'

const FindPartner = () => {
  return (
    <div>FindPartner</div>
  )
}

export default FindPartner