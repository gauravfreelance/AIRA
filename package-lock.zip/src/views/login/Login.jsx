import React from 'react'
import { Box, Grid, Paper, Stack, TextField, Typography ,Button} from "@mui/material";
import { Controller, FormProvider, useForm } from "react-hook-form";
import Colors from "../../common/Colors";
const Login = () => {
  const methods = useForm({
    full_name: "",
    email: "",
    contact_number: "+91",
});
const {
    handleSubmit,
    control,
    formState: { errors },
} = methods;
const onSubmit = (data) => {
    console.log("data", data);
};
  return (
    <Grid container spacing={2} direction="row" sx={{ my: 25, }}>
            <Grid item xs={12} sm={6} md={6} justifyContent="flex-end"  direction="row">
      <Stack
        
        alignItems="center"
        direction="row"
        justifyContent="space-between"
      >
       <img
          src="images/aboutus/about_us_header.png"
          alt="blogsHeader"
          style={{ width: "700px", height: "400px" }}
        /> 
        
        
        
      </Stack>
      </Grid>
      <FormProvider {...methods}>
                <Grid item spacing={3} sx={{ marginLeft: "5%" }}>
                    <Grid
                        item
                        xs={12}
                        
                        
                        alignItems="center"
                        justifyContent="flex-end"
                    >

                        <Stack direction="column" gap={2}>
                            <Stack direction="column" >
                                <Typography variant='h4' sx={{ fontWeight: "bold" }}>Partner Login</Typography>
                            </Stack>
                            

                            <Stack direction="column">
                                <Typography
                                    variant="body1"
                                    sx={{ fontWeight: 600, color: "#6755DF" }}
                                >
                                    First Name
                                </Typography>
                                {/* <FormHelperText
                        htmlFor="email"
                        color="muted"
                        clasSName="mb-1"
                        style={{ fontWeight: "bold" }}
                      >
                        Email
                      </FormHelperText> */}
                                <Controller
                                    rules={{ required: true }}
                                    name="email"
                                    id="email"
                                    control={control}
                                    render={({ field: { onChange, value } }) => {
                                        return (
                                            <TextField
                                                fullWidth
                                                value={value}
                                                size="small"
                                                sx={{
                                                    "& fieldset": {
                                                        //paddingLeft: (theme) => theme.spacing(2.5),
                                                        borderRadius: "10px",
                                                    },
                                                }}
                                                onChange={onChange}
                                                id="email"
                                                autoComplete="off"
                                                // size="small"
                                                type="email"
                                                variant="outlined"
                                                placeholder=""
                                                rows={10}
                                            />
                                        );
                                    }}
                                />
                                {/* <ErrorMessage
                        name="email"
                        errors={errors}
                        render={({ message }) => <p>{message}</p>}
                      /> */}
                            </Stack>
                            <Stack direction="column">
                                <Typography
                                    variant="body1"
                                    sx={{ fontWeight: 600, color: "#6755DF" }}
                                >
                                    Last Name
                                </Typography>
                                {/* <FormHelperText
                        htmlFor="full_name"
                        color="muted"
                        clasSName="mb-1"
                        style={{ fontWeight: "bold" }}
                      >
                        Full Name
                      </FormHelperText> */}
                                <Controller
                                    rules={{ required: false }}
                                    name="full_name"
                                    id="full_name"
                                    control={control}
                                    render={({ field: { onChange, value } }) => {
                                        return (
                                            <TextField
                                                sx={{
                                                    "& fieldset": {
                                                        //paddingLeft: (theme) => theme.spacing(2.5),
                                                        borderRadius: "10px",
                                                    },
                                                }}
                                                fullWidth
                                                autoFocus
                                                value={value}
                                                size="small"
                                                onChange={onChange}
                                                id="full_name"
                                                autoComplete="off"
                                                type="text"
                                                // size="small"
                                                variant="outlined"
                                                placeholder=""
                                                rows={10}
                                            />
                                        );
                                    }}
                                />

                                            {/* <ErrorMessage
                                    name="full_name"
                                    errors={errors}
                                    render={({ message }) => <p>{message}</p>}
                                /> */}
                      
                            </Stack>
                           

                            <Stack sx={{ marginTop: 1 }}>
                                <Button
                                    variant="contained"
                                    color="primary"
                                    size="large"
                                    sx={{ color: "#fff" }}
                                    fullWidth
                                    onClick={() => {
                                        handleSubmit(onSubmit)();
                                    }}
                                >
                                    Submit
                                </Button>
                                <Stack direction="column" alignItems="center" >
                                <Typography variant='p' sx={{ fontWeight: 600,color: "#6755DF"}}>Forgot your password ?</Typography>
                            </Stack>
                            </Stack>
                            
                            <Stack direction="column" alignItems="center">
                                <Typography variant='p' sx={{ fontWeight:600 }}>AIRA employee ? <span style={{ color: "#6755DF" }}> Login </span></Typography>
                            </Stack>
                            <Stack direction="column" alignItems="center">
                                <Typography variant='p' sx={{ fontWeight:600 }}>For Partner Portal Login issues, please <span style={{ color: "#6755DF" }}> contact us. </span></Typography>
                            </Stack>
                        </Stack>
                        </Grid>
                </Grid>
            </FormProvider>
      </Grid>
  )
}

export default Login