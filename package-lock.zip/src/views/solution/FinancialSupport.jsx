import React from 'react'
import { Box, Stack, Typography } from "@mui/material";
const FinancialSupport = () => {
  return (
    <Box sx={{display:"flex",justifyContent:"space-between",alignItems:"center",gap:"2rem"}}>
        <Box sx={{width:"21.875rem",padding:"1.5rem 2rem",borderRadius:"1.5rem",display:"flex",flexDirection:"column",background:"#fff"}}>
            <Typography variant='p' sx={{color:"#fff",fontWeight: 400,fontSize:"1.125rem",lineHeight:"normal",fontStyle:"normal",fontFamily: "Montserrat",textAlign:"center"}}>McKinsey</Typography>
            <Typography variant='p' >of banking processes can</Typography>
            <Typography variant='p' sx={{color:"#6755DF",fontWeight: 400,fontSize:"1.125rem",lineHeight:"normal",fontStyle:"normal",fontFamily: "Montserrat",textAlign:"center"}}>be automated</Typography>
        </Box>
    </Box>
  )
}

export default FinancialSupport