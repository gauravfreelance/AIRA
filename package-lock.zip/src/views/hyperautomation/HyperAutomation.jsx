import React from "react";

const HyperAutomation = () => {
  return <div>HyperAutomation</div>;
};

export default HyperAutomation;
